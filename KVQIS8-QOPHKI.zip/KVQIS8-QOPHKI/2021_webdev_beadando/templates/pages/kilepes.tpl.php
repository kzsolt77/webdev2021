<div class="container">

<h4>Kilépett:</h4>
<br>
<p>
<?= $data['csn']." ".$data['un']." (".$data['login'].")" ?>
</p>
</div>