<h2><?= $keres['szoveg'] ?></h2>
