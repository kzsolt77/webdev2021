<div class="container">
<h2>Adatok:</h2>
<p>Telefon: (36) 76 480 178 - munkanapokon 8-16-ig<br>
Mobil: (36) 30 9 440 759 - munkanapokon 8-16-ig <br>
Cím: 6000 Kecskemét, Boldog u. 10.<br>
Web: <a href="http://www.regram.hu" target ="_blank">www.regram.hu</a></p>
<p>Ügyvezető: <strong>Rákos Éva</strong></p>
<p>E-mail: <strong>r e g r a m [kukac] t – o n l i n e [pont] h u</strong></p>
</div>