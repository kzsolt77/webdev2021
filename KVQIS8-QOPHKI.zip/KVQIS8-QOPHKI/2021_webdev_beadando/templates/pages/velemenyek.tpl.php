<!DOCTYPE html>
<div class="container">
<h3>Beküldött vélemények</h3>
<table class="table">
        
<?php
$pdo = new PDO('mysql:host=localhost;dbname=labor7', 'root', '',
array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
$pdo->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');


$stmt = $pdo->query("SELECT * FROM bejegyzesek ORDER BY id DESC");
while ($row = $stmt->fetch()) {
    echo '<tr scope="row"><td>'.$row['nev'].'</td><td>'.$row['email'].'</td><td>'.$row['szoveg'].'</td></tr>';
}
?>
</table>
</div>
